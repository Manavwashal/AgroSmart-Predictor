import pandas as pd
import pickle

# Load the trained model
with open('model/trained_model.pkl', 'rb') as file:
    model = pickle.load(file)

# Example input data for prediction
input_data = {
    'Nitrogen': [904],
    'Phosphorus': [424],
    'Potassium': [434],
    'Temperature': [20.879744],
    'Humidity': [82.002744],
    'pH_Value': [6.502985],
    'Rainfall': [202.935536]
}

# Convert input data to DataFrame
input_df = pd.DataFrame(input_data)

# Make prediction
prediction = model.predict(input_df)

# Display prediction
print("Predicted Crop:", prediction[0])
