# import pandas as pd
# from sklearn.model_selection import train_test_split
# from sklearn.ensemble import RandomForestClassifier
# import pickle

# # Load your dataset with the correct path
# df = pd.read_csv(r"D:\AgroSmart-Predictor\Crop_Recommendation.csv")

# # Define features and target
# features = df[['Nitrogen', 'Phosphorus', 'Potassium', 'Temperature', 'Humidity', 'pH_Value', 'Rainfall','Crop']]
# target = df['label']

# # Split data into training and testing sets
# X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=2)

# # Initialize RandomForestClassifier
# model = RandomForestClassifier(n_estimators=100, random_state=42)

# # Train the model
# model.fit(X_train, y_train)

# # Save the trained model to a file
# with open(r'D:\AgroSmart-Predictor\model\trained_model.pkl', 'wb') as file:
#     pickle.dump(model, file)

# print("Model saved successfully.")







import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle

# Load your dataset with the correct path
try:
    df = pd.read_csv(r"D:\AgroSmart-Predictor\Crop_recommendation.csv", on_bad_lines='skip')
except pd.errors.ParserError as e:
    print(f"Error parsing CSV file: {e}")
    exit()

# Print column names to inspect
print("Columns in the dataset:")
print(df.columns)

# Define features and target using correct column names
features = df[['Nitrogen', 'Phosphorus', 'Potassium', 'Temperature', 'Humidity', 'pH_Value', 'Rainfall']]
target_column_name = 'Crop'  # Update this to the correct column name based on your CSV
if target_column_name in df.columns:
    target = df[target_column_name]
else:
    print(f"Error: Column '{target_column_name}' does not exist in the dataset.")
    exit()

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=2)

# Initialize RandomForestClassifier
model = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Save the trained model to a file
with open(r'D:\AgroSmart-Predictor\model\trained_model.pkl', 'wb') as file:
    pickle.dump(model, file)

print("Model saved successfully.")
