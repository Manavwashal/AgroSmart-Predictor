from flask import Flask, request, render_template
import pickle
import pandas as pd

# Load the trained model
with open('model/trained_model.pkl', 'rb') as file:
    model = pickle.load(file)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Parse incoming form data
        Nitrogen = float(request.form['N'])
        Phosphorus = float(request.form['P'])
        Potassium = float(request.form['K'])
        Temperature = float(request.form['temperature'])
        Humidity = float(request.form['humidity'])
        pH_Value = float(request.form['ph'])
        Rainfall = float(request.form['rainfall'])

        # Make prediction
        input_data = pd.DataFrame({
            'Nitrogen': [Nitrogen],
            'Phosphorus': [Phosphorus],
            'Potassium': [Potassium],
            'Temperature': [Temperature],
            'Humidity': [Humidity],
            'pH_Value': [pH_Value],
            'Rainfall': [Rainfall]
        })
        prediction = model.predict(input_data)

        # Render result HTML template with prediction
        return render_template('result.html', prediction=prediction[0])

if __name__ == '__main__':
    app.run(debug=True)
